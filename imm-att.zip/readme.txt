=== Immediate Attachments ===
Contributors: illutic WebDesign
Donate link: 
Tags: email, attachments
Requires at least: 2.7
Tested up to: 2.7.1
Stable tag: -

== Description ==

Immediate Attachments is a plugin that gives you the ability to present downloads to your visitors and receive a message immediately after the attachment(s) have been sent.

Please visit the [imm-att plugin page](http://hiranthi.illutic.nl/imm-att) for more information.


== Installation ==

Put the imm-att folder inside your wp-plugins folder. THIS PLUGIN HAS NOT BEEN TESTED WITH MU!


== Frequently Asked Questions ==

-

== Screenshots ==

Please visit the [imm-att plugin page](http://hiranthi.illutic.nl/imm-att) for screenshots & user examples.