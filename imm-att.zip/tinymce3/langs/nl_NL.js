// Dutch lang variables for WP2.5

tinyMCE.addI18n({en_US:{
WebShop:{	
desc : 'Voeg illutic WebShop product informatie toe'
}}});
