vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:57 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{B51DF30C-F9E0-4816-8648-EB7F93184D31}
vti_cacheddtm:TX|01 Apr 2009 10:01:57 -0000
vti_filesize:IR|122
vti_backlinkinfo:VX|
