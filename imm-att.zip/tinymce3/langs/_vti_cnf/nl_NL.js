vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:57 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{FB4BCBDA-81B9-4740-A2FA-3634D7F36539}
vti_cacheddtm:TX|01 Apr 2009 10:01:57 -0000
vti_filesize:IR|136
vti_backlinkinfo:VX|
