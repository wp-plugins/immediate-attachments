vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:57 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{4BC44F8E-9163-4EBA-B23F-0FBAC9827DD4}
vti_cacheddtm:TX|01 Apr 2009 10:01:57 -0000
vti_filesize:IR|131
vti_backlinkinfo:VX|
