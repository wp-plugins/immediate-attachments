// German lang variables for WP2.5

tinyMCE.addI18n({de:{
WebShop:{	
desc : 'Produkt Information hinzufuegen'
}}});
