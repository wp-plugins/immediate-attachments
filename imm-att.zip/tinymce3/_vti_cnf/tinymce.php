vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:58 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{6FB348DE-8CD5-41AC-8D8D-274E5A62FEF1}
vti_cacheddtm:TX|01 Apr 2009 10:01:58 -0000
vti_filesize:IR|1255
vti_backlinkinfo:VX|
