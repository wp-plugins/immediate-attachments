vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:57 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{F0C485E2-146A-42F5-A4E7-5F11C0ACE4D6}
vti_cacheddtm:TX|01 Apr 2009 10:01:57 -0000
vti_filesize:IR|1080
vti_backlinkinfo:VX|
