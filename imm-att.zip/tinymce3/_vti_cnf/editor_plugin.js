vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:57 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{51BF6EE8-9196-46F4-867F-C6A9921F72C7}
vti_cacheddtm:TX|01 Apr 2009 10:01:57 -0000
vti_filesize:IR|2675
vti_backlinkinfo:VX|
