vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:58 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{5B506071-608E-4AAB-8EAF-97B0A8B20614}
vti_cacheddtm:TX|01 Apr 2009 10:01:58 -0000
vti_filesize:IR|3100
vti_backlinkinfo:VX|
