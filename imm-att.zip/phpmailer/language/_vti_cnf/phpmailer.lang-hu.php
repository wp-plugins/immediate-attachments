vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:55 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{59FFC791-4E8A-460F-AD1A-3F46CA4EB3C2}
vti_cacheddtm:TX|01 Apr 2009 10:01:55 -0000
vti_filesize:IR|1276
vti_backlinkinfo:VX|
