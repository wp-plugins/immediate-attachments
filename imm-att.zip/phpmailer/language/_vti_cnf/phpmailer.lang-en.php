vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:54 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{72F0AE7B-69C5-43AC-8E65-4E6B16D0995E}
vti_cacheddtm:TX|01 Apr 2009 10:01:54 -0000
vti_filesize:IR|1197
vti_backlinkinfo:VX|
