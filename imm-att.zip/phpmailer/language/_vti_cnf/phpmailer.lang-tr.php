vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:56 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{5C404294-9715-4399-9E38-CA9BC84CDB62}
vti_cacheddtm:TX|01 Apr 2009 10:01:56 -0000
vti_filesize:IR|1255
vti_backlinkinfo:VX|
