vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:54 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{8E7FB9D2-ED36-447F-A90E-0B5C42264CFC}
vti_cacheddtm:TX|01 Apr 2009 10:01:54 -0000
vti_filesize:IR|1317
vti_backlinkinfo:VX|
