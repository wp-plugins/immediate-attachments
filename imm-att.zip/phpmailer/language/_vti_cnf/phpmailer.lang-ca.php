vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:53 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{11AB79C0-C367-4F3F-88AD-0996CC634676}
vti_cacheddtm:TX|01 Apr 2009 10:01:53 -0000
vti_filesize:IR|1226
vti_backlinkinfo:VX|
