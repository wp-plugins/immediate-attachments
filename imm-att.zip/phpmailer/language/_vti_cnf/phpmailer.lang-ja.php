vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:55 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{DDB363A1-FCE8-45FC-8E6B-9F87079020F9}
vti_cacheddtm:TX|01 Apr 2009 10:01:55 -0000
vti_filesize:IR|2672
vti_backlinkinfo:VX|
