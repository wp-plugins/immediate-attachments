vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:54 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{0D8AF473-7835-4560-B3CB-DEE5B6548A96}
vti_cacheddtm:TX|01 Apr 2009 10:01:54 -0000
vti_filesize:IR|1259
vti_backlinkinfo:VX|
