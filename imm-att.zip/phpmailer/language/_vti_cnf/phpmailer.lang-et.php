vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:54 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{BDB2CD58-9C2F-491A-9811-4B5A9109C717}
vti_cacheddtm:TX|01 Apr 2009 10:01:54 -0000
vti_filesize:IR|1277
vti_backlinkinfo:VX|
