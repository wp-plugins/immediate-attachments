vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:56 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{29D9D293-6CED-4DE2-8568-E9C95AA84A31}
vti_cacheddtm:TX|01 Apr 2009 10:01:56 -0000
vti_filesize:IR|1371
vti_backlinkinfo:VX|
