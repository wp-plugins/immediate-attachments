vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:56 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{533320A2-4655-46AC-9451-22D71EBB2B79}
vti_cacheddtm:TX|01 Apr 2009 10:01:56 -0000
vti_filesize:IR|1247
vti_backlinkinfo:VX|
