vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:54 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{8254E15C-CF0D-487C-88B8-0F6D3EA6F123}
vti_cacheddtm:TX|01 Apr 2009 10:01:54 -0000
vti_filesize:IR|1382
vti_backlinkinfo:VX|
