vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2009 10:01:55 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{D74020BB-0F45-4C10-B8EE-FA8E54FD102D}
vti_cacheddtm:TX|01 Apr 2009 10:01:55 -0000
vti_filesize:IR|1253
vti_backlinkinfo:VX|
